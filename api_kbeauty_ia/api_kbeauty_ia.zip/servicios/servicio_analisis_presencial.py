from datetime import date, datetime
from decimal import Decimal
from io import BytesIO
from pathlib import Path
from uuid import UUID, uuid4

from fastapi.responses import FileResponse
from psycopg2.extras import Json
from pypdf import PdfReader

from base_datos.conexion import consultar_uno, consultar_todos, ejecutar
from config.configuracion import obtener_configuracion
from servicios.servicio_analisis_externo import _preparar_rutina_desde_ia
from servicios.servicio_openai import analizar_pdf_externo_piel
from servicios.servicio_rutinas import obtener_resumen_rutinas
from utilidades.respuestas import respuesta_error


CARPETA_ANALISIS_PRESENCIALES = Path("almacenamiento/analisis_presenciales")
ROLES_KBEAUTY_DATA = {"admin", "administrador", "empleado", "staff", "kbeauty_data", "developer"}


def _json_seguro(valor):
    if isinstance(valor, (datetime, date)):
        return valor.isoformat()
    if isinstance(valor, UUID):
        return str(valor)
    if isinstance(valor, Decimal):
        return float(valor)
    if isinstance(valor, dict):
        return {str(k): _json_seguro(v) for k, v in valor.items()}
    if isinstance(valor, (list, tuple)):
        return [_json_seguro(v) for v in valor]
    return valor


def _asegurar_empleado(usuario):
    roles = {str(rol.get("codigo") or "").strip().lower() for rol in usuario.get("roles") or []}
    if not roles.intersection(ROLES_KBEAUTY_DATA):
        respuesta_error("No tienes permisos para usar KBEAUTY-DATA", 403)
    return True


def _obtener_usuario_cliente(usuario_id):
    usuario = consultar_uno(
        """
        SELECT u.*, p.id AS perfil_id, p.tipo_piel, p.condicion_principal
        FROM usuarios u
        LEFT JOIN perfiles_piel p ON p.villar_id = u.villar_id
        WHERE u.id = %s
        LIMIT 1
        """,
        (usuario_id,),
    )
    if not usuario:
        respuesta_error("Cliente no encontrado en Kbeauty", 404)
    return usuario


def buscar_clientes_kbeauty(texto="", limite=20):
    q = str(texto or "").strip()
    limite = max(1, min(int(limite or 20), 50))
    parametros = []
    filtro = ""
    if q:
        like = f"%{q}%"
        filtro = """
          AND (
                u.id::text ILIKE %s
             OR u.villar_id::text ILIKE %s
             OR COALESCE(p.tipo_piel, '') ILIKE %s
             OR COALESCE(p.condicion_principal, '') ILIKE %s
          )
        """
        parametros.extend([like, like, like, like])
    parametros.append(limite)
    return consultar_todos(
        f"""
        SELECT
            u.id,
            u.villar_id,
            u.estado_en_app,
            u.formulario_completado,
            u.ultimo_acceso,
            p.id AS perfil_id,
            p.tipo_piel,
            p.condicion_principal,
            p.rango_edad,
            p.sensibilidad
        FROM usuarios u
        LEFT JOIN perfiles_piel p ON p.villar_id = u.villar_id
        WHERE COALESCE(u.estado_en_app, 'activo') <> 'eliminado'
        {filtro}
        ORDER BY u.ultimo_acceso DESC NULLS LAST, u.id DESC
        LIMIT %s
        """,
        tuple(parametros),
    )


def _leer_pdf_upload(archivo_pdf):
    nombre = (archivo_pdf.filename or "analisis_presencial.pdf").strip()
    if not nombre.lower().endswith(".pdf"):
        respuesta_error("Debes subir un archivo PDF", 422)

    contenido = archivo_pdf.file.read()
    if not contenido:
        respuesta_error("El PDF esta vacio", 422)
    if len(contenido) > 25 * 1024 * 1024:
        respuesta_error("El PDF no puede superar 25 MB", 422)
    if not contenido[:8].startswith(b"%PDF"):
        respuesta_error("El archivo subido no parece ser un PDF valido", 422)
    return nombre, contenido


def _extraer_texto_pdf_bytes(contenido_pdf):
    try:
        lector = PdfReader(BytesIO(contenido_pdf))
        textos = []
        for indice, pagina in enumerate(lector.pages):
            if indice >= 15:
                break
            texto = pagina.extract_text() or ""
            if texto.strip():
                textos.append(texto.strip())
    except Exception as exc:
        respuesta_error("No se pudo leer el PDF presencial", 422, {"error": str(exc)[:300]})

    texto_final = "\n\n".join(textos).strip()
    if len(texto_final) < 40:
        respuesta_error("El PDF no tiene texto legible suficiente. Si es escaneado como imagen, exportalo con texto/OCR.", 422)
    return texto_final[:50000]


def _guardar_pdf_en_disco(analisis_id, contenido_pdf):
    CARPETA_ANALISIS_PRESENCIALES.mkdir(parents=True, exist_ok=True)
    ruta = CARPETA_ANALISIS_PRESENCIALES / f"{analisis_id}.pdf"
    ruta.write_bytes(contenido_pdf)
    return str(ruta)


def subir_analisis_presencial_pdf(usuario_empleado, usuario_id, archivo_pdf, perfil_id=None, notas=None, titulo=None):
    _asegurar_empleado(usuario_empleado)
    cliente = _obtener_usuario_cliente(usuario_id)

    perfil_final = perfil_id or cliente.get("perfil_id")
    nombre_archivo, contenido = _leer_pdf_upload(archivo_pdf)
    texto_pdf = _extraer_texto_pdf_bytes(contenido)

    analisis_ia = analizar_pdf_externo_piel(texto_pdf, obtener_resumen_rutinas())
    rutina_recomendada = _preparar_rutina_desde_ia(analisis_ia)

    analisis_id = str(uuid4())
    ruta_archivo = _guardar_pdf_en_disco(analisis_id, contenido)
    archivo_url = f"/analisis-presencial/{analisis_id}/pdf"

    valores_extraidos = {
        "origen": "presencial_pdf",
        "texto_extraido": texto_pdf[:50000],
        "analisis_ia": analisis_ia,
        "rutina_recomendada": rutina_recomendada,
    }

    registro = ejecutar(
        """
        INSERT INTO analisis_presenciales_pdf (
            id, usuario_id, perfil_id, empleado_id, titulo, tipo, etiqueta,
            archivo_nombre, archivo_ruta, archivo_url, valores_extraidos,
            estado_procesamiento, notas
        )
        VALUES (%s, %s, %s, %s, %s, 'presencial_pdf', 'Presencial', %s, %s, %s, %s, 'procesado', %s)
        RETURNING *
        """,
        (
            analisis_id,
            usuario_id,
            perfil_final,
            usuario_empleado.get("id"),
            titulo or "Analisis facial presencial",
            nombre_archivo,
            ruta_archivo,
            archivo_url,
            Json(_json_seguro(valores_extraidos)),
            notas,
        ),
        retornar=True,
    )

    return {
        "analisis_presencial": registro,
        "cliente": cliente,
        "analisis_ia": analisis_ia,
        "rutina_recomendada": rutina_recomendada,
    }


def obtener_pdf_analisis_presencial(usuario, analisis_id):
    roles = {str(rol.get("codigo") or "").strip().lower() for rol in usuario.get("roles") or []}
    es_empleado = bool(roles.intersection(ROLES_KBEAUTY_DATA))

    if es_empleado:
        registro = consultar_uno("SELECT * FROM analisis_presenciales_pdf WHERE id = %s", (analisis_id,))
    else:
        registro = consultar_uno(
            """
            SELECT ap.*
            FROM analisis_presenciales_pdf ap
            INNER JOIN usuarios u ON u.id = ap.usuario_id
            WHERE ap.id = %s AND u.villar_id = %s
            """,
            (analisis_id, usuario.get("villar_id")),
        )

    if not registro:
        respuesta_error("Analisis presencial no encontrado", 404)

    ruta = Path(registro.get("archivo_ruta") or "")
    if not ruta.exists() or not ruta.is_file():
        respuesta_error("PDF no encontrado en el servidor", 404)

    return FileResponse(
        path=str(ruta),
        media_type="application/pdf",
        filename=registro.get("archivo_nombre") or f"analisis_presencial_{analisis_id}.pdf",
        headers={"Content-Disposition": f"inline; filename=\"{registro.get('archivo_nombre') or 'analisis_presencial.pdf'}\""},
    )


def obtener_detalle_analisis_presencial(villar_id, analisis_id):
    detalle = consultar_uno(
        """
        SELECT
            ap.*,
            u.villar_id,
            p.tipo_piel,
            p.condicion_principal
        FROM analisis_presenciales_pdf ap
        INNER JOIN usuarios u ON u.id = ap.usuario_id
        LEFT JOIN perfiles_piel p ON p.id = ap.perfil_id
        WHERE ap.id = %s AND u.villar_id = %s
        """,
        (analisis_id, villar_id),
    )
    if not detalle:
        respuesta_error("Analisis presencial no encontrado", 404)
    return detalle


def validar_permiso_kbeauty_data(usuario):
    return _asegurar_empleado(usuario)
