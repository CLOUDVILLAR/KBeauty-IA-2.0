from fastapi import APIRouter, Depends, File, Form, Query, UploadFile

from dependencias.autenticacion import obtener_usuario_actual
from servicios.servicio_analisis_presencial import (
    buscar_clientes_kbeauty,
    obtener_pdf_analisis_presencial,
    obtener_detalle_analisis_presencial,
    subir_analisis_presencial_pdf,
    validar_permiso_kbeauty_data,
)
from utilidades.respuestas import respuesta_correcta

router = APIRouter(tags=["KBEAUTY-DATA"])


@router.get("/kbeauty-data/clientes/buscar")
def ruta_buscar_clientes_kbeauty(
    q: str = Query("", max_length=120),
    limite: int = Query(20, ge=1, le=50),
    usuario=Depends(obtener_usuario_actual),
):
    validar_permiso_kbeauty_data(usuario)
    clientes = buscar_clientes_kbeauty(q, limite)
    return respuesta_correcta("Clientes encontrados", clientes)


@router.post("/kbeauty-data/analisis-presencial/subir")
def ruta_subir_analisis_presencial(
    usuario_id: str = Form(...),
    perfil_id: str | None = Form(None),
    titulo: str | None = Form(None),
    notas: str | None = Form(None),
    pdf: UploadFile = File(...),
    usuario=Depends(obtener_usuario_actual),
):
    resultado = subir_analisis_presencial_pdf(
        usuario_empleado=usuario,
        usuario_id=usuario_id,
        perfil_id=perfil_id,
        titulo=titulo,
        notas=notas,
        archivo_pdf=pdf,
    )
    return respuesta_correcta("Analisis presencial subido correctamente", resultado)


@router.get("/analisis-presencial/{analisis_id}")
def ruta_detalle_analisis_presencial(analisis_id: str, usuario=Depends(obtener_usuario_actual)):
    detalle = obtener_detalle_analisis_presencial(usuario["villar_id"], analisis_id)
    return respuesta_correcta("Detalle del analisis presencial", detalle)


@router.get("/analisis-presencial/{analisis_id}/pdf")
def ruta_pdf_analisis_presencial(analisis_id: str, usuario=Depends(obtener_usuario_actual)):
    return obtener_pdf_analisis_presencial(usuario, analisis_id)
